module.exports = {
  plugins: {
    "@tailwindcss/jit": {},
    // tailwindcss: {},
    autoprefixer: {},
  },
};
